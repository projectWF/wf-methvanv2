local QBCore = exports['qb-core']:GetCoreObject()
local fans = true
local lab = true
local flasks = true
local freeze = true
local boiling = true
local build = true
local pour = true
local crystal = true
local pseudoephedrine = true
local ephedrine = true
local hydroclautic = true
local cooking = true
local smokestate = false
local placed = false
local ingrediants = false
local failedAttempts = 0
--------------------------------------------------------------------------------------------------------
-- target
--------------------------------------------------------------------------------------------------------
exports['qb-target']:AddTargetModel(`journey`, {
  options = {
      {
          type = "client",
          event = "wf:buildtab",
          icon = "fas fa-car",
          label = "van",
      },
  },
  distance = 2.5
})


exports['qb-target']:AddTargetModel(`journey`, {
  options = {
      {
          type = "client",
          event = "wf:raycast",
          icon = "fas fa-hand",
          label = "unfold lab",
      },
  },
  distance = 2.5
})

exports['qb-target']:AddTargetModel(`v_ret_ml_tablea`, {
  options = {
      {
          type = "client",
          event = "wf:cookingtab",
          icon = "fas fa-fire",
          label = "assemble",
      },
  },
  distance = 1
})

exports['qb-target']:AddTargetModel(`v_ret_ml_tablea`, {
  options = {
      {
          type = "client",
          event = "wf:ingrediantsmenu",
          icon = "fas fa-fire",
          label = "ingrediants",
      },
  },
  distance = 1
})

exports['qb-target']:AddTargetModel(`v_ret_ml_tablea`, {
  options = {
      {
          type = "client",
          event = "wf:tablepackaway",
          icon = "fas fa-hand",
          label = "pack away table",
      },
  },
  distance = 1
})

--------------------------------------------------------------------------------------------------------
-- menu    (1)
--------------------------------------------------------------------------------------------------------




RegisterNetEvent('wf:buildtab', function()
  lib.registerContext({
      id = 'van_build_menu',
      title = 'Van menu',
      options = {
        {
          title = 'Build Menu ⚒️',
          menu = 'build_menu',
          description = 'Build your van',
          metadata = {'This is where you build your van...'}
      },
      {
        title = 'Check Menu ✅',
        menu = 'check_menu',
        metadata = {'check what you have built so far!'}
    }
  }
  })
  lib.showContext('van_build_menu')
end)




--------------------------------------------------------------------------------------------------------
-- build_menu   (1)
--------------------------------------------------------------------------------------------------------




lib.registerContext({
  id = 'build_menu',
  title = 'Build menu',
  menu = 'van_build_menu',
  options = {
    {
      title = 'fans ⚒️',
      description = 'install your fans...',
      onSelect = function()
        if not fans then
          if QBCore.Functions.HasItem('fans') then
          ExecuteCommand('e mechanic')
        local success = lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 2}, 'easy'}, {'w', 'a', 's', 'd'})
        if success then 
          QBCore.Functions.Progressbar('build', 'Building ⚒️', 3000, false, true, {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true
        }, {}, {}, {}, function()
          ExecuteCommand('e c')
          fans = true
          TriggerServerEvent('wf:server:fans')
          lib.notify({
            title = 'Success',
            description = 'Installed fans',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })
        end)
        else
          ExecuteCommand('e c')
          lib.notify({
            title = 'Failed to install fans',
            description = 'couldnt Install fans',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
      else
        lib.notify({
          title = 'missing item',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })
      end
      else
        lib.notify({
          title = 'Already installed',
          description = 'fans already installed',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })
      end
      end,
      metadata = {'There might be a minigame...'}
 
    },
    {
      title = 'instal Lab 💊',
      description = 'install your lab...',
      onSelect = function()
        if not lab then
         if QBCore.Functions.HasItem('lab') then
          ExecuteCommand('e mechanic')
          local success = lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 2}, 'easy'}, {'w', 'a', 's', 'd'})
          if success then
            QBCore.Functions.Progressbar('build', 'Building ⚒️', 3000, false, true, {
              disableMovement = true,
              disableCarMovement = true,
              disableMouse = false,
              disableCombat = true
          }, {}, {}, {}, function()
            lab = true
            ExecuteCommand('e c')
            TriggerServerEvent('wf:server:lab')
            lib.notify({
              title = 'Success',
              description = 'Installed lab',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'success'
            })
            built = true
          end)
          else
            ExecuteCommand('e c')
            lib.notify({
              title = 'Failed to install lab',
              description = 'couldnt Install lab',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
          end
        else
          lib.notify({
            title = 'missing item',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
        else
          lib.notify({
            title = 'Already installed',
            description = 'lab is already installed',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
      end,
      metadata = {'There might be a minigame...'}
      
    },
    {
      title = 'Install flasks ⚗️',
      description = 'install your fans...',
      onSelect = function()
        if not flasks then
          if QBCore.Functions.HasItem('flasks') then
          ExecuteCommand('e mechanic')
          local success = lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 2}, 'easy'}, {'w', 'a', 's', 'd'})
          if success then
            QBCore.Functions.Progressbar('build', 'Building ⚒️', 3000, false, true, {
              disableMovement = true,
              disableCarMovement = true,
              disableMouse = false,
              disableCombat = true
          }, {}, {}, {}, function()
            flasks = true
            ExecuteCommand('e c')
            TriggerServerEvent('wf:server:flasks')
            lib.notify({
             title = 'Success',
             description = 'Installed flasks',
             position = 'top',
             iconAnimation = 'fade',
             style = {
               backgroundColor = '#141517'
             },
             type = 'success'
           })        
          end)
          else
            ExecuteCommand('e c')
            lib.notify({
              title = 'Failed to install flasks',
              description = 'couldnt Install flasks',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
          end
        else
          lib.notify({
            title = 'missing item',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
        else
          lib.notify({
            title = 'Already installed',
            description = 'flasks are already installed',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
      end,
      metadata = {'There might be a minigame...'}
      
    }, 
  }
})



--------------------------------------------------------------------------------------------------------
-- check_menu   (1)
--------------------------------------------------------------------------------------------------------




lib.registerContext({
  id = 'check_menu',
  title = 'Check menu',
  menu = 'van_build_menu',
  options = {
    {
      title = 'fans ⚒️',
      metadata = {'check fans'},
      onSelect = function()
        if fans then
          
          lib.notify({
            title = 'fans installed 🟢',
            description = 'fans have been installed',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })
        else
          lib.notify({
            title = 'fans not installed 🔴',
            description = 'fans have not been installed',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
      end,
    },
    {
      title = 'lab 💊',
      metadata = {'check lab'},
      onSelect = function()
        if lab then
          lib.notify({
            title = 'lab installed 🟢',
            description = 'lab has been installed',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })
        else
          lib.notify({
            title = 'lab not installed 🔴',
            description = 'lab has not been installed',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
      end,
    },
    {
      title = 'flasks ⚗️',
      metadata = {'check flasks'},
      onSelect = function()
        if flasks then
          lib.notify({
            title = 'flasks installed 🟢',
            description = 'flasks has been installed',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })
        else
          lib.notify({
            title = 'flasks not installed 🔴',
            description = 'flasks has not been installed',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
      end,
    }
  }
})




--------------------------------------------------------------------------------------------------------
-- check_build_cook   
--------------------------------------------------------------------------------------------------------





RegisterNetEvent('wf:buildcheck', function ()
  if fans then
    if flasks then
      if lab then
        local build = true
      else
        lib.notify({
          title = 'Lab missing',
          description = 'havent installed a lab dumbass...',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })
      end
    else
      lib.notify({
        title = 'flasks missing',
        description = 'just disapointing...',
        position = 'top',
        iconAnimation = 'fade',
        style = {
          backgroundColor = '#141517'
        },
        type = 'error'
      })
    end
  else
    lib.notify({
      title = 'fans missing',
      description = 'where are the fans you want to die?',
      position = 'top',
      iconAnimation = 'fade',
      style = {
        backgroundColor = '#141517'
      },
      type = 'error'
    })
  end
end)




--------------------------------------------------------------------------------------------------------
-- slider menu
--------------------------------------------------------------------------------------------------------




RegisterNetEvent('wf:ingrediantsmenu', function ()
lib.registerContext({
  id = 'ingrediants_menu',
  title = 'ingrediants menu',
  options = {
    {
      title = 'pseudoephedrine 🧪',
      metadata = 'minigame...',
      description = 'add pseudoephedrine',
      onSelect = function()
        if not pseudoephedrine then 
         if QBCore.Functions.HasItem('pseudoephedrine') then
        local success = lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 1.5}, 'medium'}, {'w', 'a', 's', 'd'})
        if success then
            ExecuteCommand('e mechanic')
                QBCore.Functions.Progressbar('pseudoephedrine', 'adding pseudoephedrine 🧪', 4000, false, true, {
                  disableMovement = true,
                  disableCarMovement = true,
                  disableMouse = false,
                  disableCombat = true
              }, {}, {}, {}, function()
                TriggerServerEvent('wf:server:pseudoephedrine')
                ExecuteCommand('e c')
                pseudoephedrine = true
            lib.notify({
            title = 'added pseudoephedrine',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })
        end)
      else
        lib.notify({
          title = 'failed adding pseudoephedrine',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })
      end
    else
      lib.notify({
        title = 'missing item',
        position = 'top',
        iconAnimation = 'fade',
        style = {
          backgroundColor = '#141517'
        },
        type = 'error'
      })
    end
      else
        lib.notify({
          title = 'already added pseudoephedrine',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })
      end
      end,
    },  {
      title = 'hydroclautic ⚗️',
      metadata = 'minigame...',
      description = 'add hydroclautic',
      onSelect = function()
        if not hydroclautic then
          if QBCore.Functions.HasItem('hydroclautic') then
        local success = lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 1.5}, 'medium'}, {'w', 'a', 's', 'd'})
        if success then
            ExecuteCommand('e mechanic')
                QBCore.Functions.Progressbar('hydroclautic', 'adding hydroclautic 🧪', 4000, false, true, {
                  disableMovement = true,
                  disableCarMovement = true,
                  disableMouse = false,
                  disableCombat = true
              }, {}, {}, {}, function()
                TriggerServerEvent('wf:server:hydroclautic')
                hydroclautic = true
                ExecuteCommand('e c')
            lib.notify({
            title = 'added hydroclautic ⚗️',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })
        end)
      else
        lib.notify({
          title = 'failed adding hydroclautic ⚗️',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })
      end
    else
      lib.notify({
        title = 'missing item',
        position = 'top',
        iconAnimation = 'fade',
        style = {
          backgroundColor = '#141517'
        },
        type = 'error'
      })
    end
      else
        lib.notify({
          title = 'already added hydroclautic ⚗️',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })
      end
      end,
    },  {
      title = 'ephedrine ⚠️',
      metadata = 'minigame...',
      description = 'add ephedrine',
      onSelect = function()

          if QBCore.Functions.HasItem('ephedrine') then
        local success = lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 1.5}, 'medium'}, {'w', 'a', 's', 'd'})
        if success then
            ExecuteCommand('e mechanic')
                QBCore.Functions.Progressbar('ephedrine', 'adding ephedrine', 4000, false, true, {
                  disableMovement = true,
                  disableCarMovement = true,
                  disableMouse = false,
                  disableCombat = true
              }, {}, {}, {}, function()
                TriggerServerEvent('wf:server:ephedrine')
                ephedrine = true
              ExecuteCommand('e c')
            lib.notify({
            title = 'added ephedrine ⚠️',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })
        end)
        else
          lib.notify({
            title = 'failed adding ephedrine ⚠️',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
      else
        lib.notify({
          title = 'missing item ephedrine ⚠️',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        }) 
      end 
      end,
    },

  }
})
lib.showContext('ingrediants_menu')
end)



--------------------------------------------------------------------------------------------------------
-- cook_menu   (2)
--------------------------------------------------------------------------------------------------------



RegisterNetEvent('wf:cookingtab', function(args)
  lib.registerContext({
    id = 'cook_tab',
    title = 'assemble ✅',
    options = {
      {
        title = 'freeze ❄️',
        onSelect = function()
          if ephedrine then 
            if hydroclautic then
              if pseudoephedrine then
          TriggerEvent('wf:freeze')
          else
            lib.notify({
              title = 'missing pseudoephedrine 🧪',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'success'
            })
          end
        else
          lib.notify({
            title = 'missing hydroclautic 🧪',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })

        end
      else
        lib.notify({
          title = 'missing ephedrine 🧪',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'success'
        })
      end
    end,
      }, {
        title = 'start boiling 🔥',
        onSelect = function()
          if not boiling then
            if freeze then
            exports["glow_minigames"]:StartMinigame(function(success)
              if success then
                ExecuteCommand('e mechanic')
                QBCore.Functions.Progressbar('boil', 'Lighting match', 4000, false, true, {
                  disableMovement = true,
                  disableCarMovement = true,
                  disableMouse = false,
                  disableCombat = true
              }, {}, {}, {}, function()
                ExecuteCommand('e c')
                lib.notify({
                  title = 'wait (30)',
                  description = 'flask is boiling...',
                  position = 'top',
                  duration = 30000,
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                Citizen.Wait(30000)
                lib.notify({
                  title = 'flask is now boiling 🔥',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                boiling = true
              end)
              else
                lib.notify({
                  title = 'failed to light the match 🔥',
                  description = 'how do you fail lighting a match?',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'error'
                })
              end
          end, "path")
          else 
            lib.notify({
              title = 'have not frozen ❄️',
              description = 'one step back buddy freeze first.',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
          end
          else
            lib.notify({
              title = 'already boiling 🔥',
              description = 'already done this step buddy',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
          end
        end,
      }, {
        title = 'start pouring ⚗️',
        metadata = 'pour the right amount...',
        onSelect = function() 
          if boiling then
            if not pour then
              ExecuteCommand('e mechanic')
            exports["glow_minigames"]:StartMinigame(function(success)
              if success then
                QBCore.Functions.Progressbar('pour', 'pouring', 3000, false, true, {
                  disableMovement = true,
                  disableCarMovement = true,
                  disableMouse = false,
                  disableCombat = true
              }, {}, {}, {}, function()
                lib.notify({
                  title = 'Poured 🧪',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                ExecuteCommand('e c')
                pour = true
                chance = math.random(1, 100)
                if chance >= 50 then
               
                lib.notify({
                  title = 'no spills?',
                  description = 'getting better',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                else
                
                  lib.notify({
                    title = 'Spilled',
                    description = 'you spilled a bit...',
                    position = 'top',
                    iconAnimation = 'fade',
                    style = {
                      backgroundColor = '#141517'
                    },
                    type = 'error'
                  })
                end
              end)
              else
                ExecuteCommand('e c')
                lib.notify({
                  title = 'fail',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'error'
                })
              end
          end, "path")
          else
            lib.notify({
              title = 'already poured',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
          end
          else
            lib.notify({
              title = 'have not boiled yet 🔥',
              description = 'one step back buddy boil first.',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
          end
        end,

      }, {
        title = 'start crytalising ❄️',
        onSelect = function()
          if pour then
            if boiling then
             if not crystal then
              ExecuteCommand('e mechanic')
             exports["glow_minigames"]:StartMinigame(function(success)
               if success then
                 QBCore.Functions.Progressbar('crystal', 'Loading chemicals in freezer', 4000, false, true, {
                   disableMovement = true,
                   disableCarMovement = true,
                   disableMouse = false,
                   disableCombat = true
               }, {}, {}, {}, function()
                
                 ExecuteCommand('e c')
                 lib.notify({
                  title = 'loaded in frezer',
                  description = 'wait (30)',
                  position = 'top',
                  duration = 29000,
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                 Citizen.Wait(30000)
                 lib.notify({
                  title = 'crystalised ❄️',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                 crystal = true
               end)
               else
                ExecuteCommand('e c')
                lib.notify({
                  title = 'fail',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'error'
                })
                 failedAttempts = failedAttempts + 1
                 if failedAttempts >= 3 then
                  lib.notify({
                    title = 'wasnt cold enough ❄️',
                    description = 'try again',
                    position = 'top',
                    iconAnimation = 'fade',
                    style = {
                      backgroundColor = '#141517'
                    },
                    type = 'error'
                  })
                 TriggerEvent('wf:cleanup')
                 else 
                 end
               end
           end, "spot")
           else
            lib.notify({
              title = 'already crystalised ❄️',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
           end
           else
            lib.notify({
              title = 'have not poured yet 🧪',
              description = 'one step back buddy pour first.',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
           end
           else
            lib.notify({
              title = 'have not poured yet 🧪',
              description = 'one step back buddy pour first.',
              position = 'top',
              iconAnimation = 'fade',
              style = {
                backgroundColor = '#141517'
              },
              type = 'error'
            })
           end
        end,

      }, {
        title = 'cooking 🔥',
          onSelect = function()
            local vehicle = GetVehiclePedIsIn(PlayerPedId())
            local ped = PlayerPedId()
            if crystal then
              ExecuteCommand('e mechanic')
              local success = lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 1.5}, 'easy'}, {'w', 'a', 's', 'd'})
              if success then
                lib.notify({
                  title = 'Get in van (10)',
                  description = 'you have 10 secound to get in van...',
                  position = 'top',
                  duration = 10000,
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
           
                ExecuteCommand('e c')
              Citizen.Wait(10000)
                   if not DoesEntityExist(vehicle) then
                    TriggerEvent('wf:cookingsmoke')
                    lib.hideTextUI()
                   end
                 else
                  ExecuteCommand('e c')
                  lib.notify({
                    title = 'failed',
                    position = 'top',
                    iconAnimation = 'fade',
                    style = {
                      backgroundColor = '#141517'
                    },
                    type = 'error'
                  })
                
                end
              else
            end
        end,
      }, {
        title = 'crack 🔨',
        metadata = 'crack the cooked ingrediants',
        onSelect = function()
          if QBCore.Functions.HasItem('meth_tray') then
          ExecuteCommand('e mechanic')
          QBCore.Functions.Progressbar('crack', 'Cracking 🔨', 4000, false, true, {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true
        }, {}, {}, {}, function()
          ExecuteCommand('e c')
          TriggerEvent('wf:cleanup')
          TriggerEvent('wf:cooking')
          TriggerServerEvent('wf:server:meth_tray')
          lib.notify({
            title = 'Cracked',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'success'
          })
        end)
      else
        lib.notify({
          title = 'missing item',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })

      end
    end,
      }
    } 
  })
 
  lib.showContext('cook_tab')
end)


--------------------------------------------------------------------------------------------------------
-- freeze function
--------------------------------------------------------------------------------------------------------




RegisterNetEvent('wf:freeze', function()
  if not freeze then
    if flasks then
      if lab then
        if fans then 
          build = true
          ExecuteCommand('e mechanic')
          exports['ps-ui']:Thermite(function(success)
            if success then
                lib.notify({
                  title = 'Freezing ❄️',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                QBCore.Functions.Progressbar('freeze', 'Freezing', 4000, false, true, {
                  disableMovement = true,
                  disableCarMovement = true,
                  disableMouse = false,
                  disableCombat = true
              }, {}, {}, {}, function()
                          
                ExecuteCommand('e c')
                lib.notify({
                  title = 'wait (30)',
                  description = 'Freezing wait to finish...',
                  position = 'top',
                  duration = 29000,
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                Citizen.Wait(30000)
                lib.notify({
                  title = 'frozen ❄️',
                  description = 'This is harder than my C***',
                  position = 'top',
                  iconAnimation = 'fade',
                  style = {
                    backgroundColor = '#141517'
                  },
                  type = 'success'
                })
                freeze = true
                ExecuteCommand('e c')
              end)
            else
              lib.notify({
                title = 'canceled',
                position = 'top',
                iconAnimation = 'fade',
                style = {
                  backgroundColor = '#141517'
                },
                type = 'error'
              })
              ExecuteCommand('e c')
            end
         end, 10, 5, 3) 
        else
          lib.notify({
            title = 'Have not completed building ⚒️',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
        else
          lib.notify({
            title = 'Have not completed building ⚒️',
            position = 'top',
            iconAnimation = 'fade',
            style = {
              backgroundColor = '#141517'
            },
            type = 'error'
          })
        end
      else 
        lib.notify({
          title = 'Have not completed building ⚒️',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'error'
        })
      end

    else
      lib.notify({
        title = 'already frozen ❄️',
        description = 'its already cold muscles',
        position = 'top',
        iconAnimation = 'fade',
        style = {
          backgroundColor = '#141517'
        },
        type = 'error'
      })
    end
end)
  



--------------------------------------------------------------------------------------------------------
-- cooking game
--------------------------------------------------------------------------------------------------------




RegisterNetEvent('wf:cookinggame', function()
  Citizen.Wait(3000)
  local failchance = math.random(1, 100)
  if failchance >= 70 then
    lib.notify({
      title = 'save cooking',
      position = 'top',
      iconAnimation = 'fade',
      style = {
        backgroundColor = '#141517'
      },
      type = 'success'
    })
  exports['ps-ui']:Circle(function(success)
    if success then
      cooking = false
      lib.notify({
        title = 'save cooking',
        position = 'top',
        iconAnimation = 'fade',
        style = {
          backgroundColor = '#141517'
        },
        type = 'success'
      })
        
  else
    cooking = false
    lib.notify({
      title = 'failed cooking',
      position = 'top',
      iconAnimation = 'fade',
      style = {
        backgroundColor = '#141517'
      },
      type = 'error'
    })
    failedAttempts = failedAttempts + 1
    if failedAttempts >= 3 then
    TriggerEvent('wf:cleanup')
    lib.notify({
      title = 'failed cooking',
      description = 'ingrediants blew up',
      position = 'top',
      iconAnimation = 'fade',
      style = {
        backgroundColor = '#141517'
      },
      type = 'error'
    })
    else
    end
  end
  end, 3, 7) 
else 
end
end)


RegisterNetEvent('wf:cooking', function()
  if not ingrediants then
    TriggerServerEvent('wf:finish')
    lib.notify({
      title = 'Cooked some meth',
      position = 'top',
      iconAnimation = 'fade',
      style = {
        backgroundColor = '#141517'
      },
      type = 'success'
    })
      TriggerEvent('wf:cleanup')
end)



--------------------------------------------------------------------------------------------------------
-- slider menu
--------------------------------------------------------------------------------------------------------
RegisterNetEvent('wf:chemicalstab', function()
  local data = lib.inputDialog("Enter Item values", {
    {
      type = "slider",
      label = "pseudoephedrine",
      icon = "fa-solid fa-flask",
      required = true
   },
    {
      type = "slider",
      label = "hydroclautic",
      icon = "fa-solid fa-flask",
      required = true
   },
    {
      type = "slider",
      label = "ephedrine",
      icon = "fa-solid fa-flask",
      required = true
   },
  })


 
end)

--------------------------------------------------------------------------------------------------------
-- cleanup
--------------------------------------------------------------------------------------------------------




RegisterNetEvent('wf:cleanup', function()
  cooking = false
  hydroclautic = false
  freeze = false
  pseudoephedrine = false
  froze = false
  boiling = false
  crystal = false
  pour = false
  smokestate = false
  failedAttempts = 0

end)


--------------------------------------------------------------------------------------------------------
-- raycast
--------------------------------------------------------------------------------------------------------



RegisterNetEvent('wf:raycast')
AddEventHandler('wf:raycast', function()
  if lab then
  if not placed then
  local enabled = false
    if not enabled then
        enabled = true
function RotationToDirection(rotation)
	local adjustedRotation =
	{
		x = (math.pi / 180) * rotation.x,
		y = (math.pi / 180) * rotation.y,
		z = (math.pi / 180) * rotation.z
	}
	local direction =
	{
		x = -math.sin(adjustedRotation.z) * math.abs(math.cos(adjustedRotation.x)),
		y = math.cos(adjustedRotation.z) * math.abs(math.cos(adjustedRotation.x)),
		z = math.sin(adjustedRotation.x)
	}
	return direction
end

function RayCastGamePlayCamera(distance)
    local cameraRotation = GetGameplayCamRot()
	local cameraCoord = GetGameplayCamCoord()
	local direction = RotationToDirection(cameraRotation)
	local destination =
	{
		x = cameraCoord.x + direction.x * distance,
		y = cameraCoord.y + direction.y * distance,
		z = cameraCoord.z + direction.z * distance
	}
	local a, b, c, d, e = GetShapeTestResult(StartShapeTestRay(cameraCoord.x, cameraCoord.y, cameraCoord.z, destination.x, destination.y, destination.z, -1, PlayerPedId(), 0))
	return b, c, e
end

function Draw2DText(content, font, colour, scale, x, y)
    SetTextFont(font)
    SetTextScale(scale, scale)
    SetTextColour(colour[1],colour[2],colour[3], 255)
    SetTextEntry("STRING")
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextDropShadow()
    SetTextEdge(4, 0, 0, 0, 255)
    SetTextOutline()
    AddTextComponentString(content)
    DrawText(x, y)
end



function math.round(input, decimalPlaces)
    return tonumber(string.format("%." .. (decimalPlaces or 0) .. "f", input))
end

Citizen.CreateThread(function()
	while true do
        local Wait = 5
        if enabled then
            local color = {r = 255, g = 255, b = 255, a = 200}
            local position = GetEntityCoords(PlayerPedId())
            local hit, coords, entity = RayCastGamePlayCamera(1000.0)
            lib.showTextUI('[E] - place table ⚒️', {
              position = "right-center",
              icon = 'hand',
              style = {
                  borderRadius = 0,
                  backgroundColor = '#141517',
                  color = 'white'
              }
          })
            DrawMarker(28, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, 0.1, 0.1, 0.1, color.r, color.g, color.b, color.a, false, true, 2, nil, nil, false)
            if IsControlJustReleased(0, 38) then
              ExecuteCommand('e mechanic')
              enabled = false
              lib.hideTextUI()
              QBCore.Functions.Progressbar('lab', 'placing lab ⚒️', 2500, false, true, {
                disableMovement = true,
                disableCarMovement = true,
                disableMouse = false,
                disableCombat = true
            }, {}, {}, {}, function()
               TriggerEvent('wf:table')
               lib.hideTextUI()
               local entity = CreateObject('v_ret_ml_tablea', coords.x, coords.y, coords.z)
               placed = true
               enabled = false
               ExecuteCommand('e c')
               lib.notify({
                title = 'placed ⚒️',
                position = 'top',
                iconAnimation = 'fade',
                style = {
                  backgroundColor = '#141517'
                },
                type = 'success'
              })
            end)
            end
        else
            local Wait = 500
        end
        Citizen.Wait(Wait)
	end
end)
    else
        enabled = false
        lib.notify({
          title = 'placed ⚒️',
          position = 'top',
          iconAnimation = 'fade',
          style = {
            backgroundColor = '#141517'
          },
          type = 'success'
        })
    end
  else
    enabled = false
    lib.notify({
      title = 'already placed ⚒️',
      position = 'top',
      iconAnimation = 'fade',
      style = {
        backgroundColor = '#141517'
      },
      type = 'error'
    })
  end
else
  lib.notify({
    title = 'Have not built Lab 💊',
    position = 'top',
    iconAnimation = 'fade',
    style = {
      backgroundColor = '#141517'
    },
    type = 'error'
  })
end
end)

 
--------------------------------------------------------------------------------------------------------
-- debugging
--------------------------------------------------------------------------------------------------------





  

    
    



--------------------------------------------------------------------------------------------------------
-- smoke and cooking
--------------------------------------------------------------------------------------------------------

RegisterNetEvent('wf:cookingsmoke', function ()
local pos = GetEntityCoords((PlayerPedId()))
local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
local policechance = math.random(1, 100)
if DoesEntityExist(vehicle) then
  local vehiclecoords = GetEntityCoords(vehicle)
  if not HasNamedPtfxAssetLoaded("core") then
    RequestNamedPtfxAsset("core")
    while not HasNamedPtfxAssetLoaded("core") do
      Wait(1)
    end
  end
  SetPtfxAssetNextCall("core")
  local smoke = StartParticleFxLoopedAtCoord('exp_grd_bzgas_smoke', vehiclecoords.x, vehiclecoords.y, vehiclecoords.z, 0, 0, 0, 1.0, 0, 0, 0, 0)
  SetParticleFxLoopedAlpha(smoke, 0.9)
  if policechance >= Config.chancepolice then
    TriggerEvent('wf:callpolice')
  end
  QBCore.Functions.Progressbar('cook', 'Cooking 🔥', 20000, false, true, {
    disableMovement = true,
    disableCarMovement = true,
    disableMouse = false,
    disableCombat = true
}, {}, {}, {}, function()
  StopParticleFxLooped(smoke, 0)
  TriggerServerEvent('wf:methtray')
  lib.notify({
    title = 'finished cooking 🔥',
    position = 'top',
    iconAnimation = 'fade',
    style = {
      backgroundColor = '#141517'
    },
    type = 'success'
})
smokestate = true
end, function()
  StopParticleFxLooped(smoke, 0)
  lib.notify({
    title = 'canceled cooking',
    position = 'top',
    iconAnimation = 'fade',
    style = {
      backgroundColor = '#141517'
    },
    type = 'error'
})
smokestate = true
  end)
end
end)

--------------------------------------------------------------------------------------------------------
-- lab_menu
--------------------------------------------------------------------------------------------------------

RegisterNetEvent('lab_menu', function(args)
  lib.registerContext({
    id = 'lab_menu',
    title = 'Lab menu',
    options = {
      {
          title = 'Lab 💊',
          metadata = {'This is where you unfold your lab 💊'},
          onSelect = function()
            TriggerEvent('wf:raycast')
          end,
      }
    }
  })
 
  lib.showContext('lab_menu')
end)

RegisterNetEvent('wf:tablepackaway', function ()
  local pos = GetEntityCoords((PlayerPedId()))
  local object = QBCore.Functions.GetClosestObject(pos)
  ExecuteCommand('e mechanic')
  QBCore.Functions.Progressbar('lab', 'packing up lab ⚒️', 2500, false, true, {
    disableMovement = true,
    disableCarMovement = true,
    disableMouse = false,
    disableCombat = true
}, {}, {}, {}, function()
  DeleteObject(object)
  placed = false 
  ExecuteCommand('e c')
  lib.notify({
    title = 'packed away ⚒️',
    position = 'top',
    iconAnimation = 'fade',
    style = {
      backgroundColor = '#141517'
    },
    type = 'success'
  })
end)
end)

RegisterCommand('callpolice', function ()
  TriggerEvent('wf:callpolice')
end)

RegisterNetEvent('wf:callpolice', function ()
  TriggerServerEvent('police:server:policeAlert', 'Meth manufacturing')
end)