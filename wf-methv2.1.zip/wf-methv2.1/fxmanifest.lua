fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'wf'
version '1.2.0'

shared_scripts {
    'config.lua',
    "@ox_lib/init.lua"
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

client_scripts {
    '@PolyZone/client.lua',
    '@PolyZone/BoxZone.lua',
    '@PolyZone/ComboZone.lua',
    'client/main.lua'
}
