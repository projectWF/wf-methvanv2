Config = {}

Config.chancepolice = 50