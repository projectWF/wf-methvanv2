local QBCore = exports['qb-core']:GetCoreObject()



RegisterServerEvent('wf:finish', function()
    local _source = source
    local xPlayer = QBCore.Functions.GetPlayer(_source)
    local bags = math.random(1, 8)
    xPlayer.Functions.AddItem('meth', bags)
    TriggerClientEvent('inventory:client:ItemBox', _source, QBCore.Shared.Items['meth'], 'add')
end)
    
    RegisterServerEvent('wf:finish2', function()
    local _source = source
    local xPlayer = QBCore.Functions.GetPlayer(_source)
    local bags = math.random(1, 8)
    xPlayer.Functions.AddItem('meth', bags)
    TriggerClientEvent('inventory:client:ItemBox', _source, QBCore.Shared.Items['meth'], 'add')
    end)
    
    RegisterServerEvent('wf:finish3', function()
        local _source = source
        local xPlayer = QBCore.Functions.GetPlayer(_source)
        local bags = math.random(20, 55)
        xPlayer.Functions.AddItem('meth', bags)
        TriggerClientEvent('inventory:client:ItemBox', _source, QBCore.Shared.Items['meth'], 'add')
    end)

    RegisterNetEvent('wf:server:lab', function() ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('lab', 1) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["lab"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)

    RegisterNetEvent('wf:server:amount', function(amount) ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('pseudoephedrine', amount) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["pseudoephedrine"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)

    RegisterNetEvent('wf:server:amount2', function(amount) ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('hydroclautic', amount) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hydroclautic"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)

    RegisterNetEvent('wf:server:amount3', function(amount) ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('ephedrine', amount) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["ephedrine"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)


    RegisterNetEvent('wf:server:fans', function() ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('fans', 1) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["fans"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)

    RegisterNetEvent('wf:server:flasks', function() ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('flasks', 1) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["flasks"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)
    
    RegisterNetEvent('wf:server:pseudoephedrine', function() ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('pseudoephedrine', 1) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["pseudoephedrine"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)

    RegisterNetEvent('wf:server:hydroclautic', function() ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('hydroclautic', 1) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hydroclautic"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)
    
    RegisterNetEvent('wf:server:ephedrine', function() ---eg,('qb-hunting:server:removeBait', function()
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        Player.Functions.RemoveItem('ephedrine', 1) ---eg, Player.Functions.RemoveItem('hunting_bait', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["ephedrine"], "remove") ---eg, TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["hunting_bait"], "remove")
    end)

